package org.example.tiedafx.ejemplo;

public interface Ejemplo {

    void ejemploMetodo2();
    void ejemploMetodo1();
}
