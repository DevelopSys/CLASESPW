package org.example.tiedafx.ejemplo;

public interface Ejemplo3 {

    void ejemploMetodo2();
    void ejemploMetodo1();
}
