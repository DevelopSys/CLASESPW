package org.example.tiedafx.ejemplo;

public interface Ejemplo2 extends Ejemplo, Ejemplo3{

    // metodoEjemplo
    // metodoEjemplo3

}
