package org.example.tiedafx.ejemplo;

import java.io.Serializable;

public class Clase implements Ejemplo2, Serializable {


    public static void main(String[] args) {
        Clase.metodo1();
    }


    public static int metodo1(){
        try{
            System.out.println("Ejecutando try");
            return 1;
        } finally {
            System.out.println("Ejecutando finally");
        }
        return 0;
    }



    @Override
    public void ejemploMetodo2() {

    }

    @Override
    public void ejemploMetodo1() {

    }
}
